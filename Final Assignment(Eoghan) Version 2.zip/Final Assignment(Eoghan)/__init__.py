import shelve

from flask import Flask, redirect, render_template, request, session, url_for
import vendor
import products
import credential
from Forms import addProductsForm, vendorform, createCredientalform

app = Flask(__name__)
app.config["SECRET_KEY"] = "This is a key"


@app.route('/', methods=["GET", "POST"])
def start():
    vendorf = vendorform(request.form)
    if request.method == 'POST' and vendorf.validate():
        vendor1_dict = {}
        db = shelve.open('vendor', 'c')

        try:
            vendor1_dict = db['vendor']
        except KeyError:
            print("No rewards stored in vendor.db yet")
        except:
            print("Other error")

        vendor1 = vendor.Vendor(vendorf.name.data,
                                 vendorf.verify.data)
        vendor1_dict[vendor1.get_vendor_id()] = vendor1
        db['vendor'] = vendor1_dict
        session["Vendor_data"] = vendorf.verify.data
        print(vendorf.verify.data)
        print(vendor1.get_name(), "was stored in vendor.db successfully")
        session["Vendor_id"] = vendor1.get_vendor_id()

        db.close()

        return redirect(url_for('home'))
    return render_template('start.html', form= vendorf)
   


@app.route('/verify' , methods=["GET", "POST"])
def home():
    try:
        vendor2 = {}
        db = shelve.open("vendor", "r")
        vendor2 = db['vendor']
        db.close()
        print("File found.")
    except:
        print("File could not be found please add la so hai")
        return redirect(url_for('start'))

    vendor = session["Vendor_data"]

    vendorid = session["Vendor_id"]
    vendorobj = vendor2.get(vendorid)

    if vendor == 'Y':
        return render_template("home.html", vendor = vendorobj)
    else:
        return render_template("unvfhome.html", vendor = vendorobj)

@app.route('/contactUs')
def contact_us():
    return render_template("contactUs.html")
#if want new page need to create new route e.g. @app.route('/products')

@app.route('/addProducts', methods=['GET', 'POST'])
def add_product():
    add_product_form = addProductsForm(request.form)
    if request.method == 'POST' and add_product_form.validate():
        products_dict = {}
        db = shelve.open('products', 'c')

        try:
            products_dict = db['products']
        except KeyError:
            print("No rewards stored in products.db yet")
        except:
            print("Other error")

        product = products.Product(add_product_form.fullname.data,
                                 add_product_form.generalclass.data,
                                 add_product_form.quantity.data,
                                 add_product_form.price.data,
                                 add_product_form.remarks.data,
                                 add_product_form.halal.data)
        products_dict[product.get_Product_id()] = product
        db['products'] = products_dict

        print(products.Product.get_fullname, "was stored in products.db successfully")

        db.close()

        return redirect(url_for('retrieve_products'))
    return render_template('addProducts.html', form= add_product_form)

@app.route('/retrieveProducts')
def retrieve_products():
    products_dict = {}
    print("help")
    try:
        db = shelve.open('products', 'r')
        products_dict = db['products']
        db.close()
    except KeyError:
        print('No rewards stored in products.db yet')
    except:
        print("Other error")

    products_list = []
    for key in products_dict:
        product = products_dict.get(key)
        products_list.append(product)
    
    print(products_list)
    print(len(products_list))


    return render_template('retrieveProducts.html', count=len(products_list), products_list=products_list) #count (number of users) and list itself
    #when render here it is a get request, need to do post request

@app.route('/deleteProduct/<int:id>', methods=['POST'])
def delete_product(id):
    products_dict = {}
    db = shelve.open('products', 'w')
    products_dict = db['products']

    products_dict.pop(id)

    db['products'] = products_dict
    db.close()

    return redirect(url_for('retrieve_products'))

@app.route('/updateProducts/<int:id>', methods=['GET', 'POST'])
def update_product(id): #not a post, is only a GET before submit (which is a post), id is a get operation
    update_product_form = addProductsForm(request.form)
    if request.method == 'POST' and update_product_form.validate(): #when you press submit after updating
        products_dict = {} #update the db
        db = shelve.open('products', 'w')
        products_dict = db['products']

        product = products_dict.get(id)
        product.set_fullname(update_product_form.fullname.data)
        product.set_generalclass(update_product_form.generalclass.data)
        product.set_quantity(update_product_form.quantity.data)
        product.set_price(update_product_form.price.data)
        product.set_halal(update_product_form.halal.data)
        product.set_remarks(update_product_form.remarks.data)
        
        db['products'] = products_dict
        db.close()

        return redirect(url_for('retrieve_products')) #sends back to retrieve users with updated data
    else:
        products_dict = {}
        db = shelve.open('products', 'r')
        products_dict = db['products']
        db.close() #will open database after entering page

        product = products_dict.get(id)
        update_product_form.fullname.data = product.get_fullname()
        update_product_form.generalclass.data = product.get_generalclass()
        update_product_form.quantity.data = product.get_quantity()
        update_product_form.price.data = product.get_price()
        update_product_form.halal.data = product.get_halal()
        update_product_form.remarks.data = product.get_remarks() #gets the user info

        return render_template('updateProducts.html', form=update_product_form) #populates the form and passes it onto the html

@app.route('/addCredentials', methods=['GET', 'POST'])
def add_credentials():
    add_credential_form = createCredientalform(request.form)
    if request.method == 'POST' and add_credential_form.validate():
        credentials_dict = {}
        db = shelve.open('credentials', 'c')

        try:
            credentials_dict = db['credentials']
        except KeyError:
            print("No credentials credentials.db yet")
        except:
            print("Other error")

                ##get last storeID
        ## increment storeID 
        mylist = list(credentials_dict.keys())
        ##print(mylist[-1])
        ##for items in mylist:
        ##    print(items)
      
        ##print(newstoreid)
        
        credentialS = credential.Credential(add_credential_form.shopname.data,
                                            add_credential_form.fulladdress.data,
                                            add_credential_form.postalcode.data,
                                            add_credential_form.region.data,
                                            add_credential_form.mainproductsold.data,
                                            add_credential_form.email.data,
                                            add_credential_form.phone.data, 
                                            add_credential_form.operatinghour.data)   

        credentials_dict[credential.Credential.get_Credential_id] = credentialS  
        db['credentials'] = credentials_dict

        print(add_credential_form.shopname.data, "was stored in credentials.db successfully")


        db.close()

        return redirect(url_for('add_credentials'))

    return render_template('addCredentials.html', form=add_credential_form)


@app.route('/viewCredentials')
def retrieve_credentials():
    
    credentials_dict = {}
    
    try:
        db = shelve.open('credentials', 'r')
        credentials_dict = db['credentials']
        db.close()
    except KeyError:
        print('No Stores.db yet')
    except:
        print("Other error")

    credentials_list = []
    for key in credentials_dict:
        credentials = credentials_dict.get(key)
        credentials_list.append(credentials)

    print(credentials_list)
    print(len(credentials_list))
    
     
    return render_template('viewCredentials.html', count=len(credentials_list), credentials_list=credentials_list)
    #when render here it is a get request, need to do post request

@app.route('/updateCredentials/<int:id>', methods=['GET', 'POST'])
def update_credential(id): #not a post, is only a GET before submit (which is a post), id is a get operation
    update_credential_form = createCredientalform(request.form)
    if request.method == 'POST' and update_credential_form.validate(): #when you press submit after updating
        credentials_dict = {} #update the db
        db = shelve.open('credentials', 'w')
        credentials_dict = db['credentials']

        credentialS = credentials_dict.get(id)
        credentialS.set_shopname(update_credential_form.shopname.data)
        credentialS.set_fulladdress(update_credential_form.fulladdress.data)
        credentialS.set_postalcode(update_credential_form.postalcode.data)
        credentialS.set_region(update_credential_form.region.data)
        credentialS.set_mainproductsold(update_credential_form.mainproductsold.data)
        credentialS.set_email(update_credential_form.email.data)
        credentialS.set_phone(update_credential_form.phone.data)
        credentialS.set_operatinghour(update_credential_form.operatinghour.data)

        db['credentials'] = credentials_dict
        db.close()

        return redirect(url_for('retrieve_credentials')) #sends back to retrieve users with updated data
    else:
        credentials_dict = {}
        db = shelve.open('credentials', 'r')
        credentials_dict = db['credentials']
        db.close() #will open database after entering page

        credentialS = credentials_dict.get(id)
        update_credential_form.shopname.data = credentialS.get_shopname()
        update_credential_form.fulladdress.data = credentialS.get_fulladdress()
        update_credential_form.postalcode.data = credentialS.get_postalcode()
        update_credential_form.region.data = credentialS.get_region()
        update_credential_form.mainproductsold.data = credentialS.get_mainproductsold()
        update_credential_form.email.data = credentialS.get_email()
        update_credential_form.phone.data = credentialS.get_phone()
        update_credential_form.operatinghour.data = credentialS.get_operatinghour() #gets the user info

        return render_template('updateCredentials.html', form=update_credential_form) #populates the form and passes it onto the html
    
@app.route('/deleteCredential/<int:id>', methods=['POST'])
def delete_credential(id):
    products_dict = {}
    db = shelve.open('credentials', 'w')
    credentials_dict = db['credentials']

    credentials_dict.pop(id)

    db['credentials'] = credentials_dict
    db.close()

    return redirect(url_for('retrieve_credentials'))
    
#always add new Flask routes above this if main statement
if __name__ == '__main__':
    app.run(debug=True)
