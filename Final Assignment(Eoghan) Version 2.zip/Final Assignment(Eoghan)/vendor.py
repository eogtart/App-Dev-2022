class Vendor:
    count_id = 0
    # Product_id = 0 #if added 3 users, if add new one id would become 1 again,  need to store in database last id added
    #everytime restart the application countid is set back to 0
    #can use timestamp with id, unique string, running number not good idea
    #need to handle user and customer id
    def __init__(self, name, verify):
        Vendor.count_id += 1
        self.__vendor_id = Vendor.count_id
        self.__count_id = Vendor.count_id #to make userid more complicated can do str(User.count) + timestamp
        self.__name = name
        self.__verify = verify

    def get_vendor_id(self):
        return self.__vendor_id

    def get_name(self):
        return self.__name

    def get_verify(self):
        return self.__verify

    def set_vendor_id(self, vendor_id):
        self.__vendor_id = vendor_id
    def set_name(self, name):
        self.__name = name

    def set_verify(self, verify):
        self.__verify = verify
