class Credential:
    count_id = 0
    #Credential_id = 0 #if added 3 users, if add new one id would become 1 again,  need to store in database last id added
    #everytime restart the application countid is set back to 0
    #can use timestamp with id, unique string, running number not good idea
    #need to handle user and customer id
    def __init__(self, shopname, fulladdress, postalcode, region, mainproductsold, email, phone, operatinghour):
        Credential.count_id += 1
        self.__Credential_id = Credential.count_id
        self.__count_id = Credential.count_id #to make userid more complicated can do str(User.count) + timestamp
        self.__shopname = shopname
        self.__fulladdress = fulladdress
        self.__postalcode = postalcode
        self.__region = region
        self.__mainproductsold = mainproductsold
        self.__email = email
        self.__phone = phone
        self.__operatinghour = operatinghour


    def get_Credential_id(self):
        return self.__Credential_id
 
    def get_shopname(self):
        return self.__shopname
 
    def get_fulladdress(self):
        return self.__fulladdress

    def get_postalcode(self):
        return self.__postalcode
 
    def get_region(self):
        return self.__region
 
    def get_mainproductsold(self):
        return self.__mainproductsold
    
    def get_email(self):
        return self.__email

    def get_phone(self):
        return self.__phone

    def get_operatinghour(self):
        return self.__operatinghour
    
    def set_Credential_id(self, Credential_id):
        self.__Credential_id = Credential_id

    def set_shopname(self, shopname):
        self.__shopname = shopname
 
    def set_fulladdress(self, fulladdress):
        self.__fulladdress = fulladdress
 
    def set_postalcode(self, postalcode):
        self.__postalcode = postalcode
    
    def set_region(self, region):
        self.__region = region
 
    def set_mainproductsold(self, mainproductsold):
        self.__mainproductsold = mainproductsold

    def set_email(self, email):
        self.__email = email

    def set_phone(self, phone):
        self.__phone = phone

    def set_operatinghour(self, operatinghour):
       self.__operatinghour = operatinghour
