from flask.scaffold import F
from flask_wtf.file import FileRequired, FileAllowed
from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators, TextAreaField, IntegerField, FloatField, FileField, SelectMultipleField
from wtforms.fields import EmailField, DateField
#wtforms.fields.html5 if have error might need to remove the html5

class addProductsForm(Form):
    fullname = StringField('Full name of product', [validators.length(min=1, max=150), validators.DataRequired()])
    category = [('', 'Select'), ('Meat', 'Meat'), ('Seafood', 'Seafood'), ('Pasta', 'Pasta, Rice & Grain'), ('Dairy' , 'Dairy products'), ('Fats', 'Fats & Oils'),('Fruits', 'Fruits'), ('Vegetables', 'Vegetables'), ('Herbs & Spices', 'Herbs & Spices'), ('Nuts', 'Nuts'), ('Others', 'Others')]
    generalclass = SelectField('Category of food product', [validators.DataRequired()], choices = category)
    quantity = IntegerField('Quantity', [validators.number_range(min=1, max=10000, message="An integer between 1 & 10000"), validators.DataRequired()])
    price = FloatField('Price per product', [validators.number_range(min=1, max=10000, message="An integer between 1 & 10000"),  validators.DataRequired()])
    # logo = FileField('Logo', validators=[FileRequired(), FileAllowed(['jpg', 'png'], 'Images only!')])
    # prize_img = FileField('Prize', validators=[FileRequired(), FileAllowed(['jpg', 'png'], 'Images only!')])
    halal = SelectField('Halal', [validators.DataRequired()], choices=[('', 'Select'), ('Y', 'Yes'), ('N', 'No')], default = '')
    remarks = TextAreaField('Product Description', [validators.length(min=1, max=200), validators.DataRequired()])
    # sample_image = FileField('Sample Image', validators=[FileRequired(), FileAllowed(['jpg', 'png'], 'Images only!')])

class vendorform(Form):
    name =  StringField('name of vendor', [validators.length(min=1, max=150), validators.DataRequired()])
    verify = SelectField('verify', [validators.DataRequired()], choices=[('', 'Select'), ('Y', 'Yes'), ('N', 'No')], default = '')


class createCredientalform(Form):
    shopname = StringField('Name of your shop',  [validators.length(min=1, max=150), validators.DataRequired()])
    fulladdress = StringField('Enter your shop address', [validators.length(min=1, max=150), validators.DataRequired()])
    postalcode = StringField('Enter your postal code', [validators.length(min=1, max=6), validators.DataRequired()])
    SG = [('', 'Select'),('Central', 'Central'), ('East', 'East'), ('North', 'North'), ('North-East', 'North-East'), ('West', 'West')]
    region = SelectField('Region of shop', [validators.DataRequired()], choices = SG)
    category = [('', 'Select'), ('Meat', 'Meat'), ('Seafood', 'Seafood'), ('Pasta', 'Pasta, Rice & Grain'), ('Dairy' , 'Dairy products'), ('Fats', 'Fats & Oils'),('Fruits', 'Fruits'), ('Vegetables', 'Vegetables'), ('Herbs & Spices', 'Herbs & Spices'), ('Nuts', 'Nuts'), ('Others', 'Others')]
    mainproductsold = SelectField('Categories of food product sold', [validators.DataRequired()], choices = category)
    email = EmailField('Email address', [validators.DataRequired()])
    phone = StringField('Phone number', [validators.length(min=1, max=8),validators.DataRequired()])
    operatinghours = StringField('Operating hours (In 00:00 - 12:00 format)',  [validators.length(min=1, max=13), validators.DataRequired()])
    




# can have two classes in one file
#there are bootstrap fields in the docs for wtforms
