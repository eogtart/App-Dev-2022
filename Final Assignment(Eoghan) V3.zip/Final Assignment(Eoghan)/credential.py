class Credential:
    count_id = 0
    #Credential_id = 0 #if added 3 users, if add new one id would become 1 again,  need to store in database last id added
    #everytime restart the application countid is set back to 0
    #can use timestamp with id, unique string, running number not good idea
    #need to handle user and customer id
    def __init__(self, shop_name, full_address, postal_code, region, main_products_sold, email, phone, operating_hours):
        Credential.count_id += 1
        self.__Credential_id = Credential.count_id
        self.__count_id = Credential.count_id #to make userid more complicated can do str(User.count) + timestamp
        self.__shop_name = shop_name
        self.__full_address = full_address
        self.__postal_code = postal_code
        self.__region = region
        self.__main_products_sold = main_products_sold
        self.__email = email
        self.__phone = phone
        self.__operating_hours = operating_hours

    def get_Credential_id(self):
        return self.__Credential_id
    
    def get_shop_name(self):
        return self.__shop_name
    
    def get_full_address(self):
        return self.__full_address
    
    def get_postal_code(self):
        return self.__postal_code
    
    def get_region(self):
        return self.__region
    
    def get_main_products_sold(self):
        return self.__main_products_sold
    
    def get_email(self):
        return self.__email
    
    def get_phone(self):
        return self.__phone
    
    def get_operating_hours(self):
        return self.__operating_hours

    def set_Credential_id(self, Credential_id):
        self.__Credential_id = Credential_id
    
    def set_shop_name(self, shop_name):
        self.__shop_name = shop_name

    def set_full_address(self, full_address):
        self.__full_address = full_address
    
    def set_postal_code(self, postal_code):
        self.__postal_code = postal_code
    
    def set_region(self, region):
        self.__region = region
    
    def set_region(self, region):
        self.__region = region
        
    def set_main_products_sold(self, main_products_sold):
        self.__main_products_sold = main_products_sold
    
    def set_email(self, email):
        self.__email = email

    def set_phone(self, phone):
        self.__phone = phone
    
    def set_operating_hours(self, operating_hours):
        self.__operating_hours = operating_hours
    

    


    
        
       