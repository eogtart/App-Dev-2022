class Product:
    count_id = 0
    # Product_id = 0 #if added 3 users, if add new one id would become 1 again,  need to store in database last id added
    #everytime restart the application countid is set back to 0
    #can use timestamp with id, unique string, running number not good idea
    #need to handle user and customer id
    def __init__(self, fullname, generalclass, quantity, price, remarks, halal):
        Product.count_id += 1
        self.__Product_id = Product.count_id
        self.__count_id = Product.count_id #to make userid more complicated can do str(User.count) + timestamp
        self.__fullname = fullname
        self.__quantity = quantity
        self.__price = price
        self.__generalclass = generalclass
        self.__remarks = remarks
   #     self.__sample_image = sample_image
        self.__halal = halal

    def get_Product_id(self):
        return self.__Product_id

    def get_fullname(self):
        return self.__fullname

    def get_generalclass(self):
        return self.__generalclass

    def get_quantity(self):
        return self.__quantity

    def get_price(self):
        return self.__price

    def get_remarks(self):
        return self.__remarks

   # def get_sample_image(self):
    #    return self.__sample_image

    def get_halal(self):
        return self.__halal


    def set_Product_id(self, Product_id):
        self.__Product_id = Product_id
    def set_fullname(self, fullname):
        self.__fullname = fullname

    def set_generalclass(self, generalclass):
        self.__generalclass = generalclass

    def set_quantity(self, quantity):
        self.__quantity = quantity

    def set_price(self, price):
        self.__price = price

    def set_remarks(self, remarks):
        self.__remarks = remarks

   # def set_sample_image(self, sample_image):
   #     self.__sample_image = sample_image

    def set_halal(self, halal):
        self.__halal = halal
